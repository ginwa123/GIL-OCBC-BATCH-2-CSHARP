# Identitas

1. Nama : Gilang Trisetya Indrawan
2. Kode Peserta : FSDO002ONL018


## Cara memakai aplikasi
----
1. ketik dotnet ef database update (untuk migrate database mysql xampp -> server=localhost;database=018gilang_movie_assignment;user=root)
2. dotnet run
3. Test API menggunakan Postman / Swagger

## ScreenShot
-----
Ada di PDF

